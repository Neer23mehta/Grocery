import a1 from "@/newimg/File-Line.svg"
import a2 from "@/newimg/File-Line2.svg"
import a3 from "@/newimg/File-Line (1).svg"
import a4 from "@/newimg/File-Line (2).svg"
import b1 from "@/newimg/Queue-icon.svg"
import b2 from "@/newimg/File-Line (3).svg"
import c1 from "@/newimg/vuesax/linear/arrow-down.svg"
import d1 from "@/newimg/File-Line (e).svg"
import a2_blue from "@/newimg/File-Line22.svg"
import a3_blue from "@/newimg/File-Line(11).svg"
import a4_blue from "@/newimg/File-Line(22).svg"
import a1_blue from "@/newimg/File-Lines.svg"
export const images = {
    a1,a2,a3,a4,b1,b2,c1,d1,a2_blue,a3_blue,a4_blue,a1_blue
}